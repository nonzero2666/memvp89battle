const express = require('express');
const mysql = require('mysql');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const cors = require('cors');

const app = express();
const port = 3001;

// ตั้งค่า CORS
app.use(cors());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'adsser_login',
    password: 'Ssaa112233++', // แก้ไขเป็นรหัสผ่านของ MySQL ของคุณ
    database: 'adsser_login'
});

db.connect(err => {
    if (err) {
        console.error('Error connecting to database:', err);
        return;
    }
    console.log('Connected to MySQL database');
});

// ตรวจสอบและสร้างโฟลเดอร์ uploads ถ้าไม่มีก็สร้าง
const uploadDir = path.join(__dirname, 'public/uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

// ตั้งค่า multer เพื่อจัดการการอัปโหลดไฟล์
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const fileFilter = (req, file, cb) => {
    // ตรวจสอบชนิดของไฟล์
    const allowedTypes = /jpeg|jpg|png|gif/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);

    if (extname && mimetype) {
        return cb(null, true);
    } else {
        cb('Error: File type not allowed!');
    }
};

const upload = multer({
    storage,
    limits: { fileSize: 1024 * 1024 * 5 }, // จำกัดขนาดไฟล์ที่ 5MB
    fileFilter
});

// ตั้งค่าเส้นทาง API สำหรับการอัปโหลดไฟล์
app.post('/api/upload', upload.array('files', 12), (req, res) => {
    const files = req.files;
    if (!files) {
        return res.status(400).json({ message: 'No files uploaded' });
    }

    const fileData = files.map(file => [file.filename, `public/uploads/${file.filename}`]);

    const sql = 'INSERT INTO images (filename, url) VALUES ?';
    db.query(sql, [fileData], (err, result) => {
        if (err) {
            console.error('Error inserting into database:', err);
            return res.status(500).json({ message: 'Database error' });
        }

        res.status(200).json({ message: "Files uploaded successfully", data: result });
    });
});

// ตั้งค่าเส้นทาง API เพื่อดึงข้อมูลไฟล์ที่อัปโหลด
app.get('/api/images', (req, res) => {
    const sql = 'SELECT * FROM images';
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Error fetching from database:', err);
            return res.status(500).json({ message: 'Database error' });
        }
        res.json(results);
    });
});

// ตั้งค่าเส้นทาง API สำหรับการลบไฟล์ตาม ID
app.delete('/api/images/:id', (req, res) => {
    const id = req.params.id;

    // Get the file info from the database
    const getFileSql = 'SELECT * FROM images WHERE id = ?';
    db.query(getFileSql, [id], (err, results) => {
        if (err) {
            console.error('Error fetching from database:', err);
            return res.status(500).json({ message: 'Database error' });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'File not found' });
        }

        const file = results[0];
        const filePath = path.join(__dirname, file.url);

        // Delete the file from the filesystem
        fs.unlink(filePath, (err) => {
            if (err) {
                console.error('Error deleting file:', err);
                return res.status(500).json({ message: 'Error deleting file' });
            }

            // Delete the file record from the database
            const deleteSql = 'DELETE FROM images WHERE id = ?';
            db.query(deleteSql, [id], (err, result) => {
                if (err) {
                    console.error('Error deleting from database:', err);
                    return res.status(500).json({ message: 'Database error' });
                }

                res.status(200).json({ message: 'File deleted successfully' });
            });
        });
    });
});

// ตั้งค่าเส้นทางสำหรับไฟล์ที่อัปโหลด
app.use('/uploads', express.static(uploadDir));

// เริ่มเซิร์ฟเวอร์
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
